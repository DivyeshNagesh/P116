function preload(){
}

function setup(){
    canvas = createCanvas(300,300);
    canvas.center();
}

function draw(){
}

function take_snapshot(){
    save("my_picture.png");
}